package com.example.learningcardroomapp;

public interface LearningCardItemClickListener {
    void onLearningCardItemClick(LearningCard learningCard);
}
